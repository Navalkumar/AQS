import React from "react";

function Analyses() {
    return (
      <div>
        <h2>Analyses</h2>
      </div>
    );
  }

  export default Analyses;