import React from "react";

function Dashboards() {
    return (
      <div>
        <h2>Dashboards</h2>
      </div>
    );
  }

  export default Dashboards;