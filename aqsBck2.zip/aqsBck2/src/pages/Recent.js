import React from 'react';

function Recent() {
  return (
    <div className='recent'>
      <h1>Recent</h1>
    </div>
  );
}

export default Recent;
