import React from 'react';

export const Header = () => {
  return (
    <div className="mb-2" color="primary">
      
    </div>
  );
};
