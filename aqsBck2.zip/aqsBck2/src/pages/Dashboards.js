import React from 'react';

function Dashboards() {
  return (
    <div className='reports'>
      <h1>Dashboards</h1>
    </div>
  );
}

export default Dashboards;
