import React from 'react';

function Favorites() {
  return (
    <div className='favorites'>
      <h1>Favorites</h1>
    </div>
  );
}

export default Favorites;
